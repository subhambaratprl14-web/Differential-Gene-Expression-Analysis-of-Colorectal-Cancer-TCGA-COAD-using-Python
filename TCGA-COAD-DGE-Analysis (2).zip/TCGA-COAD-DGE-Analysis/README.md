
# TCGA-COAD Differential Expression Analysis

Reproducible tumour-versus-normal RNA-seq analysis for the TCGA colon adenocarcinoma cohort. The pipeline uses the checked-in STAR counts and clinical metadata by default and does not download data during startup.

## Run

Use the project environment from the repository root:

```powershell
.\tcga-env\Scripts\python.exe analysis.py --skip-enrichment
```

The optional enrichment step requires network access. It is attempted by default and is skipped without invalidating the core results if the remote service is unavailable.

Outputs are written to `results/` and `figures/`: DESeq2 statistics, sample metadata, a run manifest, a volcano plot, and a heatmap when significant genes are available.

## PDF report

Create a full visual report from completed outputs:

```powershell
.\tcga-env\Scripts\python.exe report.py
```

This creates `results/TCGA-COAD_analysis_report.pdf` with the cohort summary, sample balance, top-ranked genes, volcano plot, and heatmap.

## Reproducibility

Input files can be overridden with `--counts` and `--clinical`. Use `--min-count` and `--top-genes` to document analysis choices in a run command. Results are exploratory and should not be interpreted as clinical guidance without independent validation.
