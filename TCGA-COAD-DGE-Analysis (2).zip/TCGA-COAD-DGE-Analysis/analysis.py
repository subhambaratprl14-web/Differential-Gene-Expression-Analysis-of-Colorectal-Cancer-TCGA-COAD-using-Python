"""Reproducible TCGA-COAD tumour-versus-normal differential expression pipeline."""

from __future__ import annotations

import argparse
import json
import logging
import re
from pathlib import Path

import gseapy as gp
import matplotlib.pyplot as plt
import mygene
import numpy as np
import pandas as pd
import seaborn as sns
from pydeseq2.dds import DeseqDataSet
from pydeseq2.ds import DeseqStats


LOGGER = logging.getLogger("tcga_coad")
SAMPLE_PATTERN = re.compile(r"^TCGA-[A-Z0-9]+-[A-Z0-9]+-(?P<sample>\d{2})")
DEFAULT_GENE_SET = "GO_Biological_Process_2021"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("DATA"))
    parser.add_argument("--figures-dir", type=Path, default=Path("figures"))
    parser.add_argument("--results-dir", type=Path, default=Path("results"))
    parser.add_argument("--counts", type=Path, help="Expression TSV; defaults to the checked-in STAR counts file.")
    parser.add_argument("--clinical", type=Path, help="Clinical TSV; defaults to the checked-in clinical file.")
    parser.add_argument("--skip-enrichment", action="store_true", help="Skip the optional online enrichment step.")
    parser.add_argument("--min-count", type=int, default=10)
    parser.add_argument("--top-genes", type=int, default=50)
    return parser.parse_args()


def configure_logging() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s", datefmt="%H:%M:%S")


def resolve_input(explicit: Path | None, data_dir: Path, patterns: tuple[str, ...], label: str) -> Path:
    if explicit is not None:
        if not explicit.exists():
            raise FileNotFoundError(f"{label} file does not exist: {explicit}")
        return explicit
    for pattern in patterns:
        matches = sorted(data_dir.glob(pattern))
        if matches:
            return matches[0]
    raise FileNotFoundError(f"Could not find {label} in {data_dir}. Expected one of: {', '.join(patterns)}")


def classify_sample(barcode: str) -> str:
    match = SAMPLE_PATTERN.match(str(barcode))
    if match is None:
        return "other"
    sample_code = int(match.group("sample"))
    if 1 <= sample_code <= 9:
        return "tumour"
    if 10 <= sample_code <= 19:
        return "normal"
    return "other"


def load_inputs(counts_path: Path, clinical_path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    LOGGER.info("Loading expression matrix: %s", counts_path)
    counts = pd.read_csv(counts_path, sep="\t", index_col=0)
    counts.index = counts.index.astype(str).str.split(".").str[0]
    counts = counts.loc[~counts.index.duplicated(keep="first")]
    counts = counts.apply(pd.to_numeric, errors="coerce")
    if counts.isna().any().any():
        raise ValueError("Expression matrix contains non-numeric or missing values")
    if (counts < 0).any().any():
        raise ValueError("Expression matrix contains negative values")

    clinical = pd.read_csv(clinical_path, sep="\t", usecols=["sample", "sample_type.samples"])
    clinical = clinical.rename(columns={"sample": "barcode", "sample_type.samples": "sample_type"})
    clinical = clinical.drop_duplicates("barcode").set_index("barcode")
    common = counts.columns.intersection(clinical.index)
    if common.empty:
        raise ValueError("No sample barcodes overlap between expression and clinical files")
    counts = counts.loc[:, common]
    metadata = clinical.loc[common].copy()
    metadata["condition"] = metadata.index.map(classify_sample)
    metadata.loc[metadata["sample_type"].eq("Solid Tissue Normal"), "condition"] = "normal"
    metadata.loc[metadata["sample_type"].eq("Primary Tumor"), "condition"] = "tumour"
    metadata = metadata[metadata["condition"].isin(["tumour", "normal"])]
    counts = counts.loc[:, metadata.index]
    if metadata["condition"].nunique() != 2:
        raise ValueError("Both tumour and normal samples are required for differential expression")
    LOGGER.info("Loaded %s genes across %s samples: %s", len(counts), len(metadata), metadata["condition"].value_counts().to_dict())
    return counts, metadata


def to_raw_counts(counts: pd.DataFrame) -> pd.DataFrame:
    # Xena STAR matrices in this project are log2(count + 1), not integer HTSeq counts.
    if counts.to_numpy().max() <= 30 and not np.allclose(counts.to_numpy(), counts.to_numpy().round()):
        counts = np.expm1(counts * np.log(2))
    return counts.round().clip(lower=0).astype(np.int64)


def run_differential_expression(counts: pd.DataFrame, metadata: pd.DataFrame, min_count: int) -> tuple[pd.DataFrame, DeseqDataSet]:
    filtered = counts[counts.sum(axis=1) >= min_count]
    if filtered.empty:
        raise ValueError(f"No genes remain after min-count filtering (threshold={min_count})")
    dds = DeseqDataSet(counts=filtered.T, metadata=metadata[["condition"]], design="~condition", refit_cooks=True, quiet=True)
    dds.deseq2()
    stats = DeseqStats(dds, contrast=["condition", "tumour", "normal"], quiet=True)
    stats.summary()
    results = stats.results_df.copy()
    results.insert(0, "gene", results.index)
    results = results.sort_values(["padj", "pvalue"], na_position="last")
    LOGGER.info("Tested %s genes after filtering", len(results))
    return results, dds


def save_volcano(results: pd.DataFrame, path: Path) -> None:
    plot_data = results.dropna(subset=["padj", "log2FoldChange"]).copy()
    plot_data["neg_log10_padj"] = -np.log10(plot_data["padj"].clip(lower=1e-300))
    significant = (plot_data["padj"] < 0.05) & (plot_data["log2FoldChange"].abs() > 1)
    colours = np.where(~significant, "#a6a6a6", np.where(plot_data["log2FoldChange"] > 0, "#b23a48", "#276fbf"))
    fig, ax = plt.subplots(figsize=(9, 6))
    ax.scatter(plot_data["log2FoldChange"], plot_data["neg_log10_padj"], c=colours, s=9, alpha=0.7, linewidths=0)
    ax.axhline(-np.log10(0.05), color="#555555", linestyle="--", linewidth=0.8)
    ax.axvline(1, color="#555555", linestyle="--", linewidth=0.8)
    ax.axvline(-1, color="#555555", linestyle="--", linewidth=0.8)
    ax.set(xlabel="log2 fold change (tumour vs normal)", ylabel="-log10 adjusted p-value", title="TCGA-COAD differential expression")
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def save_heatmap(results: pd.DataFrame, dds: DeseqDataSet, metadata: pd.DataFrame, path: Path, top_genes: int) -> None:
    genes = results.loc[(results["padj"] < 0.05) & (results["log2FoldChange"].abs() > 1), "gene"].head(top_genes)
    if genes.empty:
        LOGGER.warning("No significant genes available; skipping heatmap")
        return
    normed = pd.DataFrame(dds.layers["normed_counts"], index=dds.obs_names, columns=dds.var_names).T
    matrix = np.log2(normed.loc[genes] + 1)
    matrix = matrix.sub(matrix.mean(axis=1), axis=0).div(matrix.std(axis=1).replace(0, 1), axis=0)
    colours = metadata["condition"].map({"tumour": "#b23a48", "normal": "#276fbf"})
    grid = sns.clustermap(matrix, cmap="vlag", col_colors=colours, xticklabels=False, yticklabels=True, figsize=(10, 12))
    grid.savefig(path, dpi=300)
    plt.close(grid.figure)


def save_enrichment(results: pd.DataFrame, figures_dir: Path, results_dir: Path) -> bool:
    genes = results.loc[(results["padj"] < 0.05) & (results["log2FoldChange"] > 1), "gene"]
    genes = [gene.split(".")[0] for gene in genes]
    if not genes:
        LOGGER.warning("No upregulated genes available; skipping enrichment")
        return False
    try:
        mapped = mygene.MyGeneInfo().querymany(genes, scopes="ensembl.gene", fields="symbol", species="human", returnall=False)
        symbols = sorted({item["symbol"] for item in mapped if item.get("symbol")})
        if not symbols:
            LOGGER.warning("No gene symbols mapped; skipping enrichment")
            return False
        enrichment = gp.enrichr(gene_list=symbols, gene_sets=[DEFAULT_GENE_SET], organism="human", outdir=None)
        table = enrichment.results.sort_values("Adjusted P-value").head(15)
        table.to_csv(results_dir / "go_enrichment.csv", index=False)
        table = table.iloc[::-1]
        fig, ax = plt.subplots(figsize=(9, 6))
        ax.barh(table["Term"], -np.log10(table["Adjusted P-value"].clip(lower=1e-300)), color="#0f3460")
        ax.set(xlabel="-log10 adjusted p-value", title="GO biological process enrichment")
        fig.tight_layout()
        fig.savefig(figures_dir / "go_enrichment.png", dpi=300)
        plt.close(fig)
        return True
    except Exception as exc:
        LOGGER.warning("Optional enrichment failed and was skipped: %s", exc)
        return False


def main(args: argparse.Namespace) -> None:
    configure_logging()
    args.figures_dir.mkdir(parents=True, exist_ok=True)
    args.results_dir.mkdir(parents=True, exist_ok=True)
    counts_path = resolve_input(args.counts, args.data_dir, ("*star_counts*.tsv", "*counts*.tsv", "*counts*.tsv.gz"), "counts")
    clinical_path = resolve_input(args.clinical, args.data_dir, ("*clinical*.tsv", "*phenotype*.tsv", "*phenotype*.tsv.gz"), "clinical")
    counts, metadata = load_inputs(counts_path, clinical_path)
    counts = to_raw_counts(counts)
    results, dds = run_differential_expression(counts, metadata, args.min_count)
    results.to_csv(args.results_dir / "deseq2_results.csv", index=False)
    metadata.to_csv(args.results_dir / "sample_metadata.csv")
    save_volcano(results, args.figures_dir / "volcano_plot.png")
    save_heatmap(results, dds, metadata, args.figures_dir / "heatmap_top50.png", args.top_genes)
    enrichment_completed = False if args.skip_enrichment else save_enrichment(results, args.figures_dir, args.results_dir)
    manifest = {"counts": str(counts_path), "clinical": str(clinical_path), "samples": len(metadata), "genes_tested": len(results), "enrichment_completed": enrichment_completed}
    (args.results_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    LOGGER.info("Pipeline complete. Results: %s", args.results_dir)


if __name__ == "__main__":
    main(parse_args())
