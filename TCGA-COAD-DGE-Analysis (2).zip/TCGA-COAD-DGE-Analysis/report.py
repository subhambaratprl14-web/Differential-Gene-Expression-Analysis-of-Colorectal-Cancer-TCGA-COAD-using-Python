"""Create a readable PDF report from completed TCGA-COAD pipeline outputs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages


PAGE_SIZE = (8.27, 11.69)
NAVY = "#0f3460"
INK = "#1e293b"
MUTED = "#64748b"
GRID = "#dbe3ec"


def configure_report_style() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.titlesize": 15,
        "axes.labelsize": 12,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
        "figure.facecolor": "white",
    })


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", type=Path, default=Path("results"))
    parser.add_argument("--figures-dir", type=Path, default=Path("figures"))
    parser.add_argument("--output", type=Path, default=Path("results") / "TCGA-COAD_analysis_report.pdf")
    return parser.parse_args()


def add_title_page(pdf: PdfPages, manifest: dict, metadata: pd.DataFrame, results: pd.DataFrame) -> None:
    counts = metadata["condition"].value_counts()
    significant = results[results["padj"].lt(0.05) & results["log2FoldChange"].abs().gt(1)]
    figure = plt.figure(figsize=PAGE_SIZE)
    figure.text(0.08, 0.90, "TCGA-COAD", fontsize=30, weight="bold", color=NAVY)
    figure.text(0.08, 0.855, "Differential expression analysis report", fontsize=16, color=MUTED)
    figure.text(0.08, 0.785, "RUN SUMMARY", fontsize=12, weight="bold", color=NAVY)

    metrics = [
        ("Samples analysed", f"{manifest.get('samples', len(metadata))}"),
        ("Tumour samples", f"{counts.get('tumour', 0)}"),
        ("Normal samples", f"{counts.get('normal', 0)}"),
        ("Genes tested", f"{manifest.get('genes_tested', len(results)):,}"),
        ("Significant genes", f"{len(significant):,}"),
    ]
    left = 0.08
    card_width = 0.16
    gap = 0.025
    for index, (label, value) in enumerate(metrics):
        x = left + index * (card_width + gap)
        card = figure.add_axes((x, 0.655, card_width, 0.095))
        card.set_facecolor("#f1f5f9")
        card.set_xticks([])
        card.set_yticks([])
        for spine in card.spines.values():
            spine.set_color(GRID)
            spine.set_linewidth(0.8)
        card.text(0.08, 0.72, label, transform=card.transAxes, fontsize=8.5, color=MUTED, va="center")
        card.text(0.08, 0.30, value, transform=card.transAxes, fontsize=18, weight="bold", color=NAVY, va="center")

    criteria = figure.add_axes((0.08, 0.535, 0.84, 0.075))
    criteria.set_facecolor("#f8fafc")
    criteria.set_xticks([])
    criteria.set_yticks([])
    for spine in criteria.spines.values():
        spine.set_color(GRID)
    criteria.text(0.03, 0.63, "ANALYSIS CRITERIA", transform=criteria.transAxes, fontsize=9, weight="bold", color=NAVY)
    criteria.text(0.03, 0.22, "Significant genes: FDR < 0.05 and |log2FC| > 1    |    Contrast: tumour versus normal",
                  transform=criteria.transAxes, fontsize=11, color=INK)

    status = figure.add_axes((0.08, 0.43, 0.84, 0.065))
    status.set_facecolor("#fff7ed")
    status.set_xticks([])
    status.set_yticks([])
    for spine in status.spines.values():
        spine.set_color("#fed7aa")
    status.text(0.03, 0.52, "GO enrichment completed", transform=status.transAxes, fontsize=10, color=MUTED, va="center")
    status.text(0.97, 0.52, str(manifest.get("enrichment_completed", False)), transform=status.transAxes,
                fontsize=12, weight="bold", color="#9a3412", ha="right", va="center")

    figure.text(0.08, 0.31, "INTERPRETATION", fontsize=12, weight="bold", color=NAVY)
    figure.text(0.08, 0.25, "Results are exploratory and require independent biological validation.\n"
                             "Adjusted p-values use the DESeq2 multiple-testing framework.", fontsize=11, color=MUTED, linespacing=1.6)
    pdf.savefig(figure)
    plt.close(figure)


def add_sample_page(pdf: PdfPages, metadata: pd.DataFrame) -> None:
    counts = metadata["condition"].value_counts().reindex(["tumour", "normal"]).fillna(0)
    figure, axes = plt.subplots(1, 2, figsize=(11, 6.5))
    axes[0].bar(counts.index, counts.values, color=["#b23a48", "#276fbf"], width=0.6)
    axes[0].set(title="Sample composition", ylabel="Number of samples")
    axes[0].spines[["top", "right"]].set_visible(False)
    axes[1].pie(counts.values, labels=counts.index, colors=["#b23a48", "#276fbf"], autopct="%.1f%%", startangle=90)
    axes[1].set_title("Condition proportions")
    figure.suptitle("Study cohort", fontsize=20, weight="bold", color=NAVY)
    figure.tight_layout(rect=(0, 0, 1, 0.94))
    pdf.savefig(figure)
    plt.close(figure)


def add_top_genes_page(pdf: PdfPages, results: pd.DataFrame) -> None:
    selected = results[results["padj"].notna()].head(15).copy()
    selected["log2FoldChange"] = selected["log2FoldChange"].map(lambda value: f"{value:.2f}")
    selected["padj"] = selected["padj"].map(lambda value: f"{value:.2e}")
    selected = selected[["gene", "log2FoldChange", "pvalue", "padj"]]
    selected["pvalue"] = selected["pvalue"].map(lambda value: f"{value:.2e}")
    selected.columns = ["Gene", "log2 fold change", "p-value", "adjusted p-value"]
    figure, axis = plt.subplots(figsize=(11, 8.5))
    axis.axis("off")
    axis.set_title("Top genes ranked by adjusted p-value", fontsize=20, weight="bold", color=NAVY, pad=24)
    table = axis.table(cellText=selected.values, colLabels=selected.columns, loc="center", cellLoc="left", colWidths=[0.32, 0.22, 0.18, 0.24])
    table.auto_set_font_size(False)
    table.set_fontsize(12)
    table.scale(1, 2.15)
    for cell in table.get_celld().values():
        cell.set_edgecolor(GRID)
        cell.set_text_props(color=INK)
    for column in range(len(selected.columns)):
        table[(0, column)].set_facecolor(NAVY)
        table[(0, column)].set_text_props(color="white", weight="bold")
    figure.tight_layout()
    pdf.savefig(figure)
    plt.close(figure)


def add_figure_page(pdf: PdfPages, path: Path, title: str) -> None:
    figure, axis = plt.subplots(figsize=(11, 8.5))
    image = mpimg.imread(path)
    axis.imshow(image, aspect="equal")
    axis.axis("off")
    figure.suptitle(title, fontsize=20, weight="bold", color=NAVY)
    figure.tight_layout(rect=(0, 0, 1, 0.94))
    pdf.savefig(figure)
    plt.close(figure)


def main(args: argparse.Namespace) -> None:
    configure_report_style()
    manifest_path = args.results_dir / "run_manifest.json"
    metadata_path = args.results_dir / "sample_metadata.csv"
    results_path = args.results_dir / "deseq2_results.csv"
    required = [manifest_path, metadata_path, results_path]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing analysis outputs: " + ", ".join(missing))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    metadata = pd.read_csv(metadata_path, index_col=0)
    results = pd.read_csv(results_path)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with PdfPages(args.output) as pdf:
        add_title_page(pdf, manifest, metadata, results)
        add_sample_page(pdf, metadata)
        add_top_genes_page(pdf, results)
        for filename, title in [("volcano_plot.png", "Volcano plot"), ("heatmap_top50.png", "Top significant genes heatmap")]:
            path = args.figures_dir / filename
            if path.exists():
                add_figure_page(pdf, path, title)
    print(f"Created {args.output} ({args.output.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main(parse_args())
